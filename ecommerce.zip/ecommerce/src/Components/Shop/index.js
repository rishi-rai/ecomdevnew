import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getProducts } from '../../actions/GetProducts';
import { useNavigate } from 'react-router-dom';
import ShopCard from './ShopCard';

const Shop = (props) => {
    const history = useNavigate();
    const dispatch = useDispatch();
    const [productState, setProductState] = useState([]);
    const [category, setCategory] = useState("All");

    const productList = useSelector(state => state.productsList.data);
    const categoryListData = useSelector(state => state.categoryList.data);


    useEffect(async () => {

        setProductState(productList);
    }, [productList])
    useEffect(() => {

        dispatch(getProducts({
            category: "All"
        }))
    }, [])
    return <>
        filter using category :<select onChange={(event) => {

            setCategory(event.target.value)
            dispatch(getProducts({ category: event.target.value }))
        }} >
            <option value="All">All</option>
            {categoryListData.map((cat) => {
                return <option value={cat}>{cat}</option>
            })}


        </select>
        <br />
        <br />
        <br />
        {productState.length > 0 ? productState.map((product) => {
            return <div style={{ cursor: 'pointer' }} onClick={() => { history(`/shopDetails/${product.id}`) }}><ShopCard product={product} /><br /><br /></div>
        }) : <div>Getting Data ...</div>}
    </>
}

export default Shop