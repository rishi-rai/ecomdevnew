import React from "react";
import './styles.css'
const ShopCard = (props) => {

    return <>
        <div className="card">
            <img style={{ width: "20%" }} src={props.product.image} />
            <div className="container">
                <div>title:{props.product.title}</div>
                <div>category:{props.product.category}</div>
                {/* <div>description:{props.product.description}</div> */}
                <div>price : {props.product.price}</div>
                <div>rating: {props.product.rating.rate}</div>
                {/* <div>no of people raated :{props.product.rating.count}</div> */}
            </div>
        </div>
    </>
}

export default ShopCard;