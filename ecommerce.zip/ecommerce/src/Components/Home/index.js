import React, { useEffect } from 'react';
import { useDispatch } from 'react-redux';

const Home = (props) => {

    return <div>
        This is Home
    </div>
}

export default Home